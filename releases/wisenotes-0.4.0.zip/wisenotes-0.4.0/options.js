import { SARVAM_LLM_MODEL } from "./lib/sarvam.js";

const apiKey = document.getElementById("api-key");
const model = document.getElementById("model");
const status = document.getElementById("status");

initialize();

async function initialize() {
  const saved = await chrome.storage.local.get(["sarvamApiKey"]);
  apiKey.value = saved.sarvamApiKey || "";
  model.value = SARVAM_LLM_MODEL;
}

document.getElementById("toggle-key").addEventListener("click", (event) => {
  const show = apiKey.type === "password";
  apiKey.type = show ? "text" : "password";
  event.currentTarget.textContent = show ? "Hide" : "Show";
});

document.getElementById("save").addEventListener("click", async () => {
  const key = apiKey.value.trim();
  if (!key) {
    status.textContent = "Paste a Sarvam API key before saving.";
    return;
  }
  await chrome.storage.local.set({ sarvamApiKey: key });
  await chrome.storage.local.remove(["geminiApiKey", "geminiModel", "lastSuccessfulPlannerModel"]);
  status.textContent = "Saved locally. You can close this tab.";
});

document.getElementById("forget").addEventListener("click", async () => {
  await chrome.storage.local.remove(["sarvamApiKey", "geminiApiKey"]);
  apiKey.value = "";
  status.textContent = "The Sarvam API key was removed.";
});
